class LocationsApiController < ApplicationController

end
