require 'rails_helper'

RSpec.describe TransactionsController, type: :controller do

end