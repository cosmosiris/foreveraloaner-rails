
require 'rails_helper'

RSpec.describe SearchController, type: :controller do

end